﻿namespace CopyFileDemo1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCopyFrom = new System.Windows.Forms.TextBox();
            this.txtCopyTo = new System.Windows.Forms.TextBox();
            this.btnBrowseFrom = new System.Windows.Forms.Button();
            this.btnBrowseTo = new System.Windows.Forms.Button();
            this.btnCut = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Copy From : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "copy To : ";
            // 
            // txtCopyFrom
            // 
            this.txtCopyFrom.Enabled = false;
            this.txtCopyFrom.Location = new System.Drawing.Point(134, 29);
            this.txtCopyFrom.Name = "txtCopyFrom";
            this.txtCopyFrom.Size = new System.Drawing.Size(590, 22);
            this.txtCopyFrom.TabIndex = 2;
            // 
            // txtCopyTo
            // 
            this.txtCopyTo.Enabled = false;
            this.txtCopyTo.Location = new System.Drawing.Point(134, 84);
            this.txtCopyTo.Name = "txtCopyTo";
            this.txtCopyTo.Size = new System.Drawing.Size(590, 22);
            this.txtCopyTo.TabIndex = 3;
            // 
            // btnBrowseFrom
            // 
            this.btnBrowseFrom.Location = new System.Drawing.Point(730, 21);
            this.btnBrowseFrom.Name = "btnBrowseFrom";
            this.btnBrowseFrom.Size = new System.Drawing.Size(47, 33);
            this.btnBrowseFrom.TabIndex = 4;
            this.btnBrowseFrom.Text = "...";
            this.btnBrowseFrom.UseVisualStyleBackColor = true;
            this.btnBrowseFrom.Click += new System.EventHandler(this.btnBrowseFrom_Click);
            // 
            // btnBrowseTo
            // 
            this.btnBrowseTo.Location = new System.Drawing.Point(730, 78);
            this.btnBrowseTo.Name = "btnBrowseTo";
            this.btnBrowseTo.Size = new System.Drawing.Size(47, 32);
            this.btnBrowseTo.TabIndex = 5;
            this.btnBrowseTo.Text = "...";
            this.btnBrowseTo.UseVisualStyleBackColor = true;
            this.btnBrowseTo.Click += new System.EventHandler(this.btnBrowseTo_Click);
            // 
            // btnCut
            // 
            this.btnCut.Location = new System.Drawing.Point(568, 131);
            this.btnCut.Name = "btnCut";
            this.btnCut.Size = new System.Drawing.Size(75, 29);
            this.btnCut.TabIndex = 6;
            this.btnCut.Text = "C&ut";
            this.btnCut.UseVisualStyleBackColor = true;
            this.btnCut.Click += new System.EventHandler(this.btnCut_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.Location = new System.Drawing.Point(649, 131);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(75, 29);
            this.btnCopy.TabIndex = 7;
            this.btnCopy.Text = "&Copy";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 196);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.btnCut);
            this.Controls.Add(this.btnBrowseTo);
            this.Controls.Add(this.btnBrowseFrom);
            this.Controls.Add(this.txtCopyTo);
            this.Controls.Add(this.txtCopyFrom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "File System Demo 1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCopyFrom;
        private System.Windows.Forms.TextBox txtCopyTo;
        private System.Windows.Forms.Button btnBrowseFrom;
        private System.Windows.Forms.Button btnBrowseTo;
        private System.Windows.Forms.Button btnCut;
        private System.Windows.Forms.Button btnCopy;
    }
}

