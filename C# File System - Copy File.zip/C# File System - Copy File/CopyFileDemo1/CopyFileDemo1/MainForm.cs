﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// import visual basic namespace for windows progress bar
using Microsoft.VisualBasic.FileIO;
// import file system namespace
using System.IO;

namespace CopyFileDemo1
{
    public partial class MainForm : Form
    {
        // declare varibles
        string copyFrom, copyTo;
        string destFolder;
        FileInfo file; // file to be copied

        public MainForm()
        {
            InitializeComponent();

            copyFrom = string.Empty;
            copyTo = string.Empty;
            destFolder = string.Empty;
            file = null;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void btnBrowseFrom_Click(object sender, EventArgs e)
        {
            GetFile();
        }

        // get file to copy using open file dialog
        private void GetFile()
        {
            OpenFileDialog dg = new OpenFileDialog();

            // dialog to open from my videos folder
            dg.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);

            if(dg.ShowDialog() == DialogResult.OK)
            {
                txtCopyFrom.Text = dg.FileName;
                copyFrom = dg.FileName;
                file = new FileInfo(copyFrom);
            }
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            FileSystem.CopyFile(copyFrom, copyTo, UIOption.AllDialogs);

            if (MessageBox.Show("File copied successfully\nOpen destination folder?", file.Name,
                 MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                System.Diagnostics.Process.Start("explorer", destFolder);
            }
        }

        private void btnBrowseTo_Click(object sender, EventArgs e)
        {
            SetDestination();
        }

        private void btnCut_Click(object sender, EventArgs e)
        {
            FileSystem.MoveFile(copyFrom, copyTo, UIOption.AllDialogs);
            MessageBox.Show("File moved successfully");
        }

        private void SetDestination()
        {
            FolderBrowserDialog dg = new FolderBrowserDialog();

            if(dg.ShowDialog() == DialogResult.OK)
            {
                txtCopyTo.Text = dg.SelectedPath;
                copyTo = dg.SelectedPath + "\\" + file.Name;
                destFolder = copyTo;
            }
        }
    }
}
