﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SwitchDemo1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnAddToList;
        }

        // create method to add teams to the listbox
        private void AddToList(string team)
        {
            lstTeams.Items.Add(team);

            // clear textbox & return curser
            txtTeam.Clear();
            txtTeam.Focus();
        }

        private void btnAddToList_Click(object sender, EventArgs e)
        {
            // invoke method
            AddToList(txtTeam.Text);
        }

        // create a method that will display country of the selected team on the listbox
        private void DisplayCountry(string _team)
        {
            string country = string.Empty;

            // switch statement
            switch (_team)// expression to be evaluated : _team
            {
                case "liverpool":
                case "chelsea":
                case "arsenal": country = "england";break;
                case "barcelona":
                case "real madrid":country = "spain";break;
                case "milan":country = "italy";break;
                case "bayern":country = "germany";break;
                case "psg":country = "france";break;
                default:country= "unspecified";break;
            }

            MessageBox.Show(country, "Country", MessageBoxButtons.OK,
                 MessageBoxIcon.Information);
        }


        // invoke method inside another method
        private void DisplayTeamCountry()
        {
            string team = string.Empty;

            if(lstTeams.SelectedIndex >= 0) // if any team on the listbox is selected
            {
                team = lstTeams.SelectedItem.ToString(); // assign selected team to variable : team
            }

            // call method
            DisplayCountry(team);
        }

        private void lstTeams_SelectedIndexChanged(object sender, EventArgs e)
        {
            DisplayTeamCountry();
        }
    }
}
