﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConstructorDemo1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            txtName.Focus();
            this.AcceptButton = btnDisplay;
        }

        // create class object using constructor
        private void CreateStudent()
        {
            Student s = new ConstructorDemo1.Student(txtName.Text,
                (int)nudAge.Value, txtSubject.Text);

            string output = s.Name + "\n"
                + s.Age.ToString() + "\n"
                + s.MajorSubject;

            MessageBox.Show(output,"Student");
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            CreateStudent();
        }
    }
}
