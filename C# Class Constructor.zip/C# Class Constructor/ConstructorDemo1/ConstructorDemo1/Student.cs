﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo1
{
    class Student
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string MajorSubject { get; set; }

        // constructor with parameters
        public Student(string _name, int _age, string _majorSubject)
        {
            // this refers to the class we are defining : Student
            this.Name = _name;
            this.Age = _age;
            this.MajorSubject = _majorSubject;
        }
    }
}
