﻿namespace If_ElseDemo1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dtpDOB = new System.Windows.Forms.DateTimePicker();
            this.btnAgeGroup = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Date of Birth :";
            // 
            // dtpDOB
            // 
            this.dtpDOB.Location = new System.Drawing.Point(35, 49);
            this.dtpDOB.Name = "dtpDOB";
            this.dtpDOB.Size = new System.Drawing.Size(276, 22);
            this.dtpDOB.TabIndex = 1;
            // 
            // btnAgeGroup
            // 
            this.btnAgeGroup.Location = new System.Drawing.Point(89, 189);
            this.btnAgeGroup.Name = "btnAgeGroup";
            this.btnAgeGroup.Size = new System.Drawing.Size(166, 34);
            this.btnAgeGroup.TabIndex = 2;
            this.btnAgeGroup.Text = "Show Age Group";
            this.btnAgeGroup.UseVisualStyleBackColor = true;
            this.btnAgeGroup.Click += new System.EventHandler(this.btnAgeGroup_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(371, 273);
            this.Controls.Add(this.btnAgeGroup);
            this.Controls.Add(this.dtpDOB);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "If...Else Statement";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpDOB;
        private System.Windows.Forms.Button btnAgeGroup;
    }
}

