﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace If_ElseDemo1
{
    public partial class MainForm : Form
    {
        // declare variables
        string ageGroup;
        int age;

        public MainForm()
        {
            InitializeComponent();

            // initialize variables to default values
            age = 0;
            ageGroup = string.Empty;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // set default button
            this.AcceptButton = btnAgeGroup;
        }

        // create method to return age
        private int GetAge(DateTime dateOfBirth)
        {
            age = DateTime.Now.Year - dateOfBirth.Year;
            return age;
        }

        // create a method that will display age group based on age
        private void ShowAgeGroup()
        {
            int _age = GetAge(dtpDOB.Value);

            if(_age >= 0 && _age <= 1)
            {
                ageGroup = "Infant";
            }
            else if (_age > 1 && _age <= 5)
            {
                ageGroup = "Toddler";
            }
            else if (_age > 5 && _age <= 12)
            {
                ageGroup = "Child";
            }
            else if (_age > 12 && _age <= 17)
            {
                ageGroup = "Teenager";
            }
            else if (_age > 17 && _age < 60)
            {
                ageGroup = "Adult";
            }
            else
            {
                ageGroup = "Senior Citizen";
            }

            // output
            string output = "Age \t : " + _age + "\n"
                          + "Group \t : " + ageGroup;

            MessageBox.Show(output, "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAgeGroup_Click(object sender, EventArgs e)
        {
            // invoke method
            ShowAgeGroup();
        }
    }
}
