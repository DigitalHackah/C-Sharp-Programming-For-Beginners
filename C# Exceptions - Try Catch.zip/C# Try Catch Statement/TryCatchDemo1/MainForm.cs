﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TryCatchDemo1
{
    public partial class MainForm : Form
    {
        // declare variables
        string productName;
        decimal price;
        int quantity;
        bool isValid;
        string output;

        public MainForm()
        {
            InitializeComponent();

            // initialize variables to default values
            productName = string.Empty;
            price = 0;
            quantity = 0;
            isValid = false;
            output = string.Empty;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnDisplay;
        }

        // method to get valid product name
        private bool ValidProductName(string _productName)
        {
            if(_productName.Length == 0)
            {
                isValid = false;
                txtProductName.Focus();
                throw new Exception("You have to provide product name");
            }
            else
            {
                productName = _productName;
                isValid = true;
            }
            return isValid;
        }

        // method to get valid price
        private bool ValidPrice(string _price)
        {
            if(decimal.TryParse(_price, out price))
            {
                isValid = true;
            }
            else
            {
                isValid = false;
                txtPrice.Focus();
                txtPrice.SelectAll();
                throw new Exception("The value for price does not represent money");
            }
            return isValid;
        }

        // method to get valid quantity
        private bool ValidQuantity(string _quantity)
        {
            if (int.TryParse(_quantity, out quantity))
            {
                isValid = true;
            }
            else
            {
                isValid = false;
                txtQuantity.Focus();
                txtQuantity.SelectAll();
                throw new Exception("The value for quantity is not a whole number");
            }
            return isValid;
        }

        // method to display product info
        private void DisplayProductInfo()
        {
            try
            {
                if (ValidProductName(txtProductName.Text) == true
                && ValidPrice(txtPrice.Text) == true
                && ValidQuantity(txtQuantity.Text) == true)
                {
                    output += "Product Name \t : " + productName + "\n"
                            + "Price \t\t : " + price.ToString("c") + "\n"
                            + "Quantity \t\t : " + quantity;

                    MessageBox.Show(output, "Product", MessageBoxButtons.OK,
                         MessageBoxIcon.Information);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK,
                         MessageBoxIcon.Error);
            }

            output = string.Empty;
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            // call method
            DisplayProductInfo();
        }
    }
}
