﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MethodDemo1
{
    public partial class MainForm : Form
    {
        // declare variables
        string firstName, lastName;
        int age;

        public MainForm()
        {
            InitializeComponent();

            // initialize variables to default values
            firstName = string.Empty;
            lastName = string.Empty;
            age = 0;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void btnStudentInfo_Click(object sender, EventArgs e)
        {
            // invoke method
            //ShowStudentInfo();
            ShowStudentDetails();
        }

        // create method which does not return a value
        private void ShowStudentInfo()
        {
            firstName = "John";
            lastName = "Doe";
            age = 25;

            // output for display
            string output = string.Empty;

            output += "First Name \t : " + firstName
                + "\n" + "Last Name \t : " + lastName
                + "\n" + "Age \t\t : " + age;

            MessageBox.Show(output, "Student Info",
                 MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // create method which has a return value : int
        private int GetStudentAge()
        {
            age = 23;
            return age;
        }

        // create method which has a return value : string
        private string GetStudentName()
        {
            firstName = "Jane";
            lastName = "Doe";
            return firstName + " " + lastName;
        }

        // create method to invoke methods with return values
        private void ShowStudentDetails()
        {
            string output = string.Empty;

            output += "Full Name \t : " + GetStudentName()// method that returns string value
                + "\n" + "Age \t\t : " + GetStudentAge();// method that returns int value

            MessageBox.Show(output, "Student Info",
                 MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
