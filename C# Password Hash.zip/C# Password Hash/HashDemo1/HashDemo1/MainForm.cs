﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// import namespaces
using System.IO;
using System.Security.Cryptography;

namespace HashDemo1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            btnHide.Visible = false;
            txtPassword.UseSystemPasswordChar = true;
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            btnHide.Show();
            btnShow.Hide();
            txtPassword.UseSystemPasswordChar = false;
        }

        private void btnHide_Click(object sender, EventArgs e)
        {
            btnHide.Hide();
            btnShow.Show();
            txtPassword.UseSystemPasswordChar = true;
        }

        // method to generate hash
        private string GetHashValue(string password)
        {
            // hash algorithm
            //HashAlgorithm sha = SHA1.Create();
            HashAlgorithm md5 = MD5.Create();

            // generate hash
            byte[] hashData = md5.ComputeHash(UnicodeEncoding.Default.GetBytes(password));

            // return string value of hash
            return Convert.ToBase64String(hashData);
        }

        private void btnShowHash_Click(object sender, EventArgs e)
        {
            string msgBoxHeader = "Hash value of : " + txtPassword.Text;
            MessageBox.Show(GetHashValue(txtPassword.Text), msgBoxHeader,
                 MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if(GetHashValue(txtPassword.Text) == GetHashValue(txtConfirm.Text))
            {
                MessageBox.Show("Passwords are the same");
            }
            else
            {
                MessageBox.Show("Passwords are not the same");
            }
        }
    }
}
