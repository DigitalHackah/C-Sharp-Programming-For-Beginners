﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoopsDemo1
{
    public partial class MainForm : Form
    {
        // declare array
        string[] uefaTeams;

        string output;

        public MainForm()
        {
            InitializeComponent();

            // instantiate array
            uefaTeams = new string[5];  // array will hold 5 values
            output = string.Empty;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // invoke loadarray method on project start up
            LoadArray();
        }

        // method to insert values into array
        private void LoadArray()
        {
            uefaTeams[0] = "liverpool";
            uefaTeams[1] = "barcelona";
            uefaTeams[2] = "inter milan";
            uefaTeams[3] = "arsenal";
            uefaTeams[4] = "dortmund";

            // get size of array
            int max = uefaTeams.Length;

            // set maximum property of numericUpDown control
            // make maximun property similar to index max value of array
            nudIndex.Maximum = max - 1;
        }

        // method to show contents of array
        private void ShowArrayContents()
        {
            MessageBox.Show(output, "Array Content", MessageBoxButtons.OK,
                 MessageBoxIcon.Information);
        }

        // foreach loop method
        private void ForeachLoop()
        {
            // clear output content
            output = string.Empty;

            foreach (string team in uefaTeams)
            {
                output += team + "\n";
            }
        }

        private void btnForeach_Click(object sender, EventArgs e)
        {
            // invoke foreach method and display method
            ForeachLoop();
            ShowArrayContents();
        }

        // do...while loop method
        private void DoWhileLoop(int startFrom)
        {
            // clear output content
            output = string.Empty;

            /*
             * the size of the array = 5
             * we want to read the contents of the array from a specific index
             * here we specify from which index of the array to start reading from
             * if we want to read from liverpool, which is situated at index : 0
             * then we select 0 from the numericUpDown control
             */

            int i = startFrom;

            do
            {
                output += uefaTeams[i] + "\n"; // this code will execute regardless
                i++; // if the value of i is 0 at this stage, then increase it to 1
            } while (i < uefaTeams.Length); // continue execution if i < 5 (array size)
        }

        private void btnDoWhile_Click(object sender, EventArgs e)
        {
            // method call
            DoWhileLoop((int)nudIndex.Value);
            ShowArrayContents();
        }

        // while loop method
        private void WhileLoop(int startFrom)
        {
            // clear output content
            output = string.Empty;

            /*
             * the size of the array = 5
             * we want to read the contents of the array from a specific index
             * here we specify from which index of the array to start reading from
             * if we want to read from liverpool, which is situated at index : 0
             * then we select 0 from the numericUpDown control
             */

            int i = startFrom;

            while(i < uefaTeams.Length) // condition to be evaluated
            {
                output += uefaTeams[i] + "\n"; // this code executes if condition is true
                i++; // may or may not update condition. in this case increment i by 1
                     // not updating condition may result in unexpected behavior like infinite loop
            }
        }

        private void btnWhile_Click(object sender, EventArgs e)
        {
            // invoke method
            WhileLoop((int)nudIndex.Value);
            ShowArrayContents();
        }

        // for loop method
        private void ForLoop(int startFrom)
        {
            // clear output content
            output = string.Empty;

            /*
             * the size of the array = 5
             * we want to read the contents of the array from a specific index
             * here we specify from which index of the array to start reading from
             * if we want to read from liverpool, which is situated at index : 0
             * then we select 0 from the numericUpDown control
             */

            for(int i = startFrom; i < uefaTeams.Length; i++)
            {
                output += uefaTeams[i] + "\n";
            }
        }

        private void btnFor_Click(object sender, EventArgs e)
        {
            // method call
            ForLoop((int)nudIndex.Value);
            ShowArrayContents();
        }
    }
}
