﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LinqDemo1
{
    public partial class MainForm : Form
    {
        // declare variable
        List<string> teams;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // call method at project start up
            AddToListbox();
            txtPredicate.Focus();
        }

        // insert teams into list collection
        private void InsertTeams()
        {
            teams = new List<string>() { "liverpool", "arsenal", "chelsea",
           "bayern munchen", "borossia dortmund", "bayer leverkusen",
           "barcelona","real madrid","atletico madrid",
           "ac milan","inter milan", "manchester united"};
        }

        // add teams to listbox
        private void AddToListbox()
        {
            InsertTeams();

            foreach(string team in teams)
            {
                lstTeams.Items.Add(team);
            }
        }

        private void radWordContains_CheckedChanged(object sender, EventArgs e)
        {
            txtPredicate.Focus();
        }

        // Linq Contains method
        private void WordContains(string value)
        {
            lstTeams.Items.Clear();

            var query = from t in teams    // from teams in the collection
                        where t.Contains(value)  // teams which contain the letters
                        //orderby t ascending
                        orderby t descending
                        select t; // select those teams

            if(query.ToList().Count > 0) // teams which contain the specified letters
            {
                foreach(string _team in query)
                {
                    lstTeams.Items.Add(_team); // add them to the listbox
                }
            }
        }

        // Linq EndsWith method
        private void WordEndsWith(string value)
        {
            lstTeams.Items.Clear();

            var query = from t in teams
                        where t.EndsWith(value)
                        //orderby t ascending
                        orderby t descending
                        select t;

            if (query.ToList().Count > 0)
            {
                foreach (string _team in query)
                {
                    lstTeams.Items.Add(_team);
                }
            }
        }

        // Linq Letters more than in a word
        private void LettersMoreThan(int value)
        {
            lstTeams.Items.Clear();

            var query = from t in teams
                        where t.Length > value
                        //orderby t ascending
                        orderby t descending
                        select t;

            if (query.ToList().Count > 0)
            {
                foreach (string _team in query)
                {
                    lstTeams.Items.Add(_team);
                }
            }
        }

        private void txtPredicate_TextChanged(object sender, EventArgs e)
        {
            if(txtPredicate.Text.Length > 0) // if the textbox is not empty
            {
                if(radWordContains.Checked == true) // if the radio button is checked
                {
                    WordContains(txtPredicate.Text); // if name of team contains specified letters
                }
                else if (radLettersMoreThan.Checked == true)
                {
                    LettersMoreThan(int.Parse(txtPredicate.Text));
                }
                else if(radWordEndsWith.Checked == true)
                {
                    WordEndsWith(txtPredicate.Text);
                }
            }
            else
            {
                lstTeams.Items.Clear();
                AddToListbox();
            }
        }
    }
}
