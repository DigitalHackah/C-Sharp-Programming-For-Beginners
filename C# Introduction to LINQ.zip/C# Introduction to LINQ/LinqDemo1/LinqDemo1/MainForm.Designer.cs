﻿namespace LinqDemo1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lstTeams = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPredicate = new System.Windows.Forms.TextBox();
            this.radWordContains = new System.Windows.Forms.RadioButton();
            this.radWordEndsWith = new System.Windows.Forms.RadioButton();
            this.radLettersMoreThan = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Football Teams :";
            // 
            // lstTeams
            // 
            this.lstTeams.FormattingEnabled = true;
            this.lstTeams.ItemHeight = 16;
            this.lstTeams.Location = new System.Drawing.Point(29, 59);
            this.lstTeams.Name = "lstTeams";
            this.lstTeams.Size = new System.Drawing.Size(144, 228);
            this.lstTeams.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(204, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Predicate :";
            // 
            // txtPredicate
            // 
            this.txtPredicate.Location = new System.Drawing.Point(207, 59);
            this.txtPredicate.Name = "txtPredicate";
            this.txtPredicate.Size = new System.Drawing.Size(145, 22);
            this.txtPredicate.TabIndex = 0;
            this.txtPredicate.TextChanged += new System.EventHandler(this.txtPredicate_TextChanged);
            // 
            // radWordContains
            // 
            this.radWordContains.AutoSize = true;
            this.radWordContains.Location = new System.Drawing.Point(207, 100);
            this.radWordContains.Name = "radWordContains";
            this.radWordContains.Size = new System.Drawing.Size(122, 21);
            this.radWordContains.TabIndex = 4;
            this.radWordContains.TabStop = true;
            this.radWordContains.Text = "Word Contains";
            this.radWordContains.UseVisualStyleBackColor = true;
            this.radWordContains.CheckedChanged += new System.EventHandler(this.radWordContains_CheckedChanged);
            // 
            // radWordEndsWith
            // 
            this.radWordEndsWith.AutoSize = true;
            this.radWordEndsWith.Location = new System.Drawing.Point(207, 139);
            this.radWordEndsWith.Name = "radWordEndsWith";
            this.radWordEndsWith.Size = new System.Drawing.Size(131, 21);
            this.radWordEndsWith.TabIndex = 5;
            this.radWordEndsWith.TabStop = true;
            this.radWordEndsWith.Text = "Word Ends With";
            this.radWordEndsWith.UseVisualStyleBackColor = true;
            this.radWordEndsWith.CheckedChanged += new System.EventHandler(this.radWordContains_CheckedChanged);
            // 
            // radLettersMoreThan
            // 
            this.radLettersMoreThan.AutoSize = true;
            this.radLettersMoreThan.Location = new System.Drawing.Point(207, 177);
            this.radLettersMoreThan.Name = "radLettersMoreThan";
            this.radLettersMoreThan.Size = new System.Drawing.Size(122, 21);
            this.radLettersMoreThan.TabIndex = 6;
            this.radLettersMoreThan.TabStop = true;
            this.radLettersMoreThan.Text = "Letters > Than";
            this.radLettersMoreThan.UseVisualStyleBackColor = true;
            this.radLettersMoreThan.CheckedChanged += new System.EventHandler(this.radWordContains_CheckedChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 323);
            this.Controls.Add(this.radLettersMoreThan);
            this.Controls.Add(this.radWordEndsWith);
            this.Controls.Add(this.radWordContains);
            this.Controls.Add(this.txtPredicate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstTeams);
            this.Controls.Add(this.label1);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Linq Example 1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstTeams;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPredicate;
        private System.Windows.Forms.RadioButton radWordContains;
        private System.Windows.Forms.RadioButton radWordEndsWith;
        private System.Windows.Forms.RadioButton radLettersMoreThan;
    }
}

