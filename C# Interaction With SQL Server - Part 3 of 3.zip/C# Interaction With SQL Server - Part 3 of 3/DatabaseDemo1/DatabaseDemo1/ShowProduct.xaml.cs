﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DatabaseDemo1
{
    /// <summary>
    /// Interaction logic for ShowProduct.xaml
    /// </summary>
    public partial class ShowProduct : Window
    {
        // declare variable
        List<Product> products;

        public ShowProduct()
        {
            InitializeComponent();
        }

        private void winShowProduct_Loaded(object sender, RoutedEventArgs e)
        {
            // show products when window loads
            ShowProducts();
        }

        // method to display products read from database
        private void ShowProducts()
        {
            products = Product.GetAllProducts(); // static method defined in our class

            if(products.Count > 0) // if there are products to return
            {
                // populate datagrid
                dtgProducts.ItemsSource = products;
            }
        }
    }
}
