﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace DatabaseDemo1
{
    class Product
    {
        // class design : attributes/properties
        public string Barcode { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal CostPrice { get; set; }
        public decimal RetailPrice { get; set; }
        public int Quantity { get; set; }

        // database address
        private static string connString = "Data Source=DESKTOP-8R3IHK2;Initial Catalog=LiquorStoreDB;Integrated Security=True";

        // method to save product to database
        public static bool SaveNewProduct(Product p)
        {
            bool isSaved = false;

            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_AddNewProduct";

            // sql command syntax to add parameters
            cmd.Parameters.Add(new SqlParameter("@Barcode", p.Barcode));
            cmd.Parameters.Add(new SqlParameter("@ProductName", p.ProductName));
            cmd.Parameters.Add(new SqlParameter("@Description", p.Description));
            cmd.Parameters.Add(new SqlParameter("@CostPrice", p.CostPrice));
            cmd.Parameters.Add(new SqlParameter("@RetailPrice", p.RetailPrice));
            cmd.Parameters.Add(new SqlParameter("@Quantity", p.Quantity));

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                isSaved = true;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK,
                     MessageBoxImage.Error);
            }
            finally
            {
                conn.Close(); // this code executes regardless
            }

            return isSaved;
        }

        // method to check if barcode exists in the database table
        public static bool Exists(string barcode)
        {
            // we assume it does not exist
            bool exists = false;

            // create sql connection instance & give it connstring as argument
            SqlConnection conn = new SqlConnection(connString);

            // retrieve barcode from products table
            string sql = "select Barcode from Products";

            try
            {
                // our bridge between this project & the database
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);

                // local copy of database
                DataSet ds = new DataSet();
                da.Fill(ds, "Products");

                // local copy of table
                DataTable dt = ds.Tables["Products"];

                if (dt.Rows.Count > 0) // if there is some data in the table
                {
                    // we start reading from index : 0
                    int i = 0; 

                    while (i < dt.Rows.Count && !exists)
                    {
                        if (dt.Rows[i]["Barcode"].ToString() == barcode)
                        {
                            exists = true; // if barcode is found
                        }
                        else
                        {
                            i++; // otherwise we search from the next index
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR"
                    , MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                conn.Close();
            }
            return exists;
        }

        // method to read all products from database
        public static List<Product> GetAllProducts()
        {
            // currently we dont have an object of class:Product
            Product p = null;

            // we need a list to hold what we read from database
            List<Product> products = new List<Product>();

            SqlConnection conn = new SqlConnection(connString);

            // select all columns from product table
            string sql = "select * from Products";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter(sql, conn); // bridge

                DataSet ds = new DataSet(); // local database copy

                // using the bridge, fill dataset
                da.Fill(ds, "Products");
                DataTable dt = ds.Tables["Products"];

                int i = 0;
                int max = dt.Rows.Count; // number of rows in the table

                if (max > 0)
                {
                    while (i < max)
                    {
                        // while code executes, create product instance
                        p = new Product();

                        // assign values read from database to class properties
                        p.Barcode = dt.Rows[i]["Barcode"].ToString();
                        p.ProductName = dt.Rows[i]["ProductName"].ToString();
                        p.Description = dt.Rows[i]["Description"].ToString();
                        p.CostPrice = decimal.Parse(dt.Rows[i]["CostPrice"].ToString());
                        p.RetailPrice = decimal.Parse(dt.Rows[i]["RetailPrice"].ToString());
                        p.Quantity = int.Parse(dt.Rows[i]["Quantity"].ToString());

                        // then add to list
                        products.Add(p);
                        i++; // increment index value
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "ERROR"
                    , MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                conn.Close();
            }
            return products;
        }
    }
}
