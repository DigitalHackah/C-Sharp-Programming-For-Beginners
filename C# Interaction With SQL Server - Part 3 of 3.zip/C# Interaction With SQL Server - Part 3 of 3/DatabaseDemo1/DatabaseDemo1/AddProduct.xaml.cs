﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DatabaseDemo1
{
    /// <summary>
    /// Interaction logic for AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Window
    {
        // declare variables
        Product p;
        string barcode, productName, description;
        decimal costPrice, retailPrice;
        int quantity;

        bool isValid; // error handling
        string output;

        public AddProduct()
        {
            InitializeComponent();

            // initialization
            p = null;

            barcode = string.Empty;
            productName = string.Empty;
            description = string.Empty;
            costPrice = 0;
            retailPrice = 0;
            quantity = 0;

            isValid = false;
            output = string.Empty;
        }

        private void winAddProduct_Loaded(object sender, RoutedEventArgs e)
        {
            txtBarcode.Focus();
            btnSaveProduct.IsDefault = true; // when press enter this button executes
        }

        // get valid barcode
        private bool GetBarcode()
        {
            if(txtBarcode.Text == string.Empty)
            {
                isValid = false;
                txtBarcode.Focus();
                throw new Exception("You have to provide barcode");
            }
            else
            {
                barcode = txtBarcode.Text;
                isValid = true;
            }
            return isValid;
        }

        // get valid product name
        private bool GetProductName()
        {
            if (txtProductName.Text == string.Empty)
            {
                isValid = false;
                txtProductName.Focus();
                throw new Exception("You have to provide product name");
            }
            else
            {
                productName = txtProductName.Text;
                isValid = true;
            }
            return isValid;
        }

        // get valid description
        private bool GetDescription()
        {
            if (txtDescription.Text == string.Empty)
            {
                isValid = false;
                txtDescription.Focus();
                throw new Exception("You have to provide description");
            }
            else
            {
                description = txtDescription.Text;
                isValid = true;
            }
            return isValid;
        }

        // get valid cost price
        private bool GetCostPrice()
        {
            if (decimal.TryParse(txtCostPrice.Text, out costPrice))
            {
                isValid = true;
            }
            else
            {
                isValid = false;
                txtCostPrice.Focus();
                throw new Exception("the cost price value does not represent money");
            }
            return isValid;
        }

        // get valid retail price
        private bool GetRetailPrice()
        {
            if (decimal.TryParse(txtRetailPrice.Text, out retailPrice))
            {
                isValid = true;
            }
            else
            {
                isValid = false;
                txtRetailPrice.Focus();
                throw new Exception("the retail price value does not represent money");
            }
            return isValid;
        }

        private void btnSaveProduct_Click(object sender, RoutedEventArgs e)
        {
            SaveProduct();
        }

        private void txtBarcode_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(Product.Exists(txtBarcode.Text) == true)
            {
                MessageBox.Show("Product already exists", "Found", MessageBoxButton.OK,
                     MessageBoxImage.Warning);

                txtBarcode.SelectAll();
            }
        }

        private void btnShowProducts_Click(object sender, RoutedEventArgs e)
        {
            ShowProduct win = new DatabaseDemo1.ShowProduct();
            win.ShowDialog();
        }

        // get valid quantity
        private bool GetQuantity()
        {
            if (int.TryParse(txtQuantity.Text, out quantity))
            {
                isValid = true;
            }
            else
            {
                isValid = false;
                txtQuantity.Focus();
                throw new Exception("the quantity value is not a whole number");
            }
            return isValid;
        }

        // save product
        private void SaveProduct()
        {
            if(GetBarcode() == true && GetProductName() == true
                && GetDescription() == true && GetCostPrice() == true
                && GetRetailPrice() == true && GetQuantity() == true)
            {
                try
                {
                    p = new DatabaseDemo1.Product();

                    p.Barcode = barcode;
                    p.ProductName = productName;
                    p.Description = description;
                    p.CostPrice = costPrice;
                    p.RetailPrice = retailPrice;
                    p.Quantity = quantity;

                    if (Product.SaveNewProduct(p) == true)
                    {
                        MessageBox.Show("Product saved successfully", "Product",
                             MessageBoxButton.OK, MessageBoxImage.Information);

                        ClearControls();
                        txtBarcode.Focus();
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error",
                             MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // clear controls
        private void ClearControls()
        {
            txtBarcode.Clear();
            txtProductName.Clear();
            txtDescription.Clear();
            txtCostPrice.Clear();
            txtRetailPrice.Clear();
            txtQuantity.Clear();
        }
    }
}
