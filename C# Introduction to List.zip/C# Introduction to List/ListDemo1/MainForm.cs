﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListDemo1
{
    public partial class MainForm : Form
    {
        // declare list
        //List<string> teams;

        // list initialization
        List<string> teams = new List<string>() { "aston villa", "psg", "napoli"};

        public MainForm()
        {
            InitializeComponent();

            // instantiate/create list
            //teams = new List<string>();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnDisplay;

            // invoke populateList method on project start up
            AddToList();
        }

        // method to populate list with values
        private void AddToList()
        {
            /* This is 1 of the other ways of adding items to a list
            teams.Add("liverpool"); // index : 0
            teams.Add("chelsea"); // index : 1
            teams.Add("arsenal"); // index : 2
            teams.Add("real madrid"); // index : 3
            teams.Add("barcelona"); // index : 4
            */

            // get size of list
            int max = teams.Count;

            // set numericUpDown maximum
            // modify numericUpDown maximum property to match max index value of list
            nudListIndex.Maximum = max - 1; 
        }

        // display teams
        private void DisplayTeams()
        {
            string output = teams[(int)nudListIndex.Value];
            MessageBox.Show(output, "Team", MessageBoxButtons.OK,
                 MessageBoxIcon.Information);
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            // invoke method
            DisplayTeams();
        }
    }
}
