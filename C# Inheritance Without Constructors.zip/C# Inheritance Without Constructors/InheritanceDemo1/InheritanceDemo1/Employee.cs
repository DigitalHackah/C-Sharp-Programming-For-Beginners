﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo1
{
    // child class will inherit from Person class
    class Employee : Person
    {
        public string Department { get; set; }
        public string JobType { get; set; }
    }
}
