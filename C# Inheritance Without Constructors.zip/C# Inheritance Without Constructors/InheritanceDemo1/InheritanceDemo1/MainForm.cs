﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InheritanceDemo1
{
    public partial class MainForm : Form
    {
        // declare variables
        Student student;
        Employee emp;
        string firstName, lastName;
        string output, msgHeader;

        public MainForm()
        {
            InitializeComponent();

            student = null; // currently no object of student has been created
            emp = null;
            firstName = string.Empty;
            lastName = string.Empty;
            output = string.Empty;
            msgHeader = string.Empty;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadDegree();
            LoadDepartment();
            LoadJobType();
            Loadsubject();
            grpEmployee.Hide();
            grpStudent.Hide();
            this.AcceptButton = btnSubmit;
            txtFirstName.Focus();
        }

        private void radEmployee_CheckedChanged(object sender, EventArgs e)
        {
            grpEmployee.Show();
            grpStudent.Hide();

            msgHeader = "Employee"; // message box header
        }

        private void radStudent_CheckedChanged(object sender, EventArgs e)
        {
            grpStudent.Show();
            grpEmployee.Hide();

            msgHeader = "Student";
        }

        // populate combo box
        private void LoadDegree()
        {
            cmbDegree.Items.Add("computer science");
            cmbDegree.Items.Add("law");
            cmbDegree.Items.Add("education");
            cmbDegree.Items.Add("engineering");
        }

        private void Loadsubject()
        {
            cmbSubject.Items.Add("sql server");
            cmbSubject.Items.Add("family law");
            cmbSubject.Items.Add("mathematics");
            cmbSubject.Items.Add("electronics");
        }

        private void LoadDepartment()
        {
            cmbDepartment.Items.Add("admin");
            cmbDepartment.Items.Add("lecturer");
            cmbDepartment.Items.Add("maintanance");
            cmbDepartment.Items.Add("finance");
        }


        private void LoadJobType()
        {
            cmbJobType.Items.Add("filing");
            cmbJobType.Items.Add("teaching");
            cmbJobType.Items.Add("electrician");
            cmbJobType.Items.Add("book keeper");
        }

        // create person instance
        private void CreatePerson()
        {
            firstName = txtFirstName.Text;
            lastName = txtLastName.Text;

            output += firstName + " " + lastName + "\n";

            if(radStudent.Checked == true)
            {
                student = new InheritanceDemo1.Student();
                student.FirstName = firstName;
                student.LastName = lastName;
                student.Degree = cmbDegree.SelectedItem.ToString();
                student.MajorSubject = cmbSubject.SelectedItem.ToString();

                output += student.Degree + "\n"
                    + student.MajorSubject;
            }
            else if (radEmployee.Checked==true)
            {
                emp = new Employee();
                emp.FirstName = firstName;
                emp.LastName = lastName;
                emp.Department = cmbDepartment.SelectedItem.ToString();
                emp.JobType = cmbJobType.SelectedItem.ToString();

                output += emp.Department + "\n"
                    + emp.JobType;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            CreatePerson();
            ShowInfo();
        }

        // clear controls
        private void ClearControls()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            cmbDegree.SelectedIndex = -1;
            cmbDepartment.SelectedIndex = -1;
            cmbJobType.SelectedIndex = -1;
            cmbSubject.SelectedIndex = -1;
        }

        // display applicant info
        private void ShowInfo()
        {
            MessageBox.Show(output, msgHeader, MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            ClearControls();
            output = string.Empty;
            msgHeader = string.Empty;
        }
    }
}
