﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassDemo1
{
    class Product
    {
        // class design : attributes/properties
        public string Barcode { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public decimal CostPrice { get; set; }
        public decimal RetailPrice { get; set; }
        public int Quantity { get; set; }
    }
}
