﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassDemo1
{
    public partial class MainForm : Form
    {
        // declare class variable
        Product p;

        // declare list variable
        List<Product> products;

        public MainForm()
        {
            InitializeComponent();

            // create list
            products = new List<Product>();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnDisplay;
            txtBarcode.Focus();
        }

        // method to create class object
        private void CreateProduct()
        {
            p = new ClassDemo1.Product();

            p.Barcode = txtBarcode.Text;
            p.ProductName = txtProductName.Text;
            p.Description = txtDescription.Text;
            p.CostPrice = decimal.Parse(txtCostPrice.Text);
            p.RetailPrice = decimal.Parse(txtRetailPrice.Text);
            p.Quantity = (int)nudQuantity.Value;
        }

        // method to display product
        private void DisplayProduct()
        {
            string output = "Barcode \t\t : " + p.Barcode + "\n"
                        + "Product Name \t : " + p.ProductName + "\n"
                        + "Description \t : " + p.Description + "\n"
                        + "Cost Price \t : " + p.CostPrice.ToString("c") + "\n"
                        + "Retail Price \t : " + p.RetailPrice.ToString("c") + "\n"
                        + "Quantity \t\t : " + p.Quantity;

            MessageBox.Show(output, "Product", MessageBoxButtons.OK,
                 MessageBoxIcon.Information);
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            // call methods
            CreateProduct();
            DisplayProduct();
        }
    }
}
