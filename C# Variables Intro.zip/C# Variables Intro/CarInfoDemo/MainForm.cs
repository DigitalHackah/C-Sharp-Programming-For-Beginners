﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarInfoDemo
{
    public partial class MainForm : Form
    {
        // declare variables
        string registrationNumber;
        string carMake;
        int topSpeed;
        decimal price;
        string color;
        int quantity;
        bool isBrandNew;

        public MainForm()
        {
            InitializeComponent();

            // initialize variable to default value
            registrationNumber = string.Empty;
            carMake = string.Empty;
            topSpeed = 0;
            price = 0;
            color = string.Empty;
            quantity = 0;
            isBrandNew = false;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // make btnDisplayInfo default : execute when press enter
            this.AcceptButton = btnDisplayInfo;

            // call or invoke method when the main form loads
            LoadDefaultColors();
        }

        private void btnDisplayInfo_Click(object sender, EventArgs e)
        {
            // what happens when this button(btnDisplayInfo) is clicked
            registrationNumber = txtRegNumber.Text;
            carMake = txtCarMake.Text;

            // topspeed + price
            topSpeed = int.Parse(txtTopSpeed.Text);
            price = decimal.Parse(txtPrice.Text);

            if (cmbColor.SelectedIndex >= 0)
            {
                color = cmbColor.SelectedItem.ToString();
            }
            else
            {
                color = string.Empty;
            }

            quantity = (int)nudQuantity.Value;

            if(radYes.Checked == true)
            {
                isBrandNew = true;
            }
            else if(radNo.Checked == true)
            {
                isBrandNew = false;
            }

            // final output/display on message box
            // we will declare a variable to hold all details about a car
            string display = string.Empty;

            // lets make output more readable : "\n" represents next line
            // the + sign we add values together
            // Instead of using colons, we can use tabstop : "\t" or both
            display += "Reg Number \t : " + registrationNumber
                + "\n" + "Car Make \t : " + carMake
                + "\n" + "Top Speed \t : " + topSpeed + " mph"
                + "\n" + "Car Price \t\t : " + price.ToString("c")// "c" represents currency
                + "\n" + "Car Color \t : " + color
                + "\n" + "Quantity \t\t : " + quantity
                + "\n" + "Is New Car \t ? " + isBrandNew;

            MessageBox.Show(display, "Car Info",
                 MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // populate combobox with values inside a method
        private void LoadDefaultColors()
        {
            cmbColor.Items.Add("blue");
            cmbColor.Items.Add("red");
            cmbColor.Items.Add("black");
            cmbColor.Items.Add("yellow");
        }

    }
}
