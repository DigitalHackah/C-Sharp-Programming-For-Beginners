﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArrayDemo1
{
    public partial class MainForm : Form
    {
        // declare array
        // string[] cars;

        // array initialization
        // string[] cars = { "mercedes", "bmw", "golf", "audi" };
        string[] cars = new string[] { "mercedes", "bmw", "golf", "audi" };

        public MainForm()
        {
            InitializeComponent();

            // instantiate/create array
            // cars = new string[4]; // this array will hold 4 values
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnDisplay;

            // Populate array method must execute when form loads
            PopulateArray();
        }

        // create method to insert values into array
        private void PopulateArray()
        {
            /* this is another way of inserting values into array
            cars[0] = "polo";
            cars[1] = "toyota";
            cars[2] = "ford";
            cars[3] = "honda";
            */

            // lets get size of array
            int max = cars.Length;

            // numeric up down must have maximum value as array size
            // maximum value of array index is 3
            nudArrayIndex.Maximum = max - 1;
        }

        // lets create method to display array value
        private void DisplayCar()
        {
            string output = cars[(int)nudArrayIndex.Value]; // index we select from numericUpDown

            MessageBox.Show(output, "Car", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            // invoke method to display array value
            DisplayCar();
        }
    }
}
