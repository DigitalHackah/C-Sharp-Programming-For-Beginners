﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MethodDemo2
{
    public partial class MainForm : Form
    {
        // declare variables
        string firstName, lastName;
        int age;

        public MainForm()
        {
            InitializeComponent();

            // initialize variables to default values
            firstName = string.Empty;
            lastName = string.Empty;
            age = 0;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.AcceptButton = btnDisplayInfo;
        }

        private void btnDisplayInfo_Click(object sender, EventArgs e)
        {
            // invoke method & pass expected arguments
            //ShowStudentInfo(txtFirstName.Text, txtLastName.Text, dtpDOB.Value);
            DisplayInfo();
        }

        // create a method which does not return a value & accepts parameters
        private void ShowStudentInfo(string _firstName, string _lastName, DateTime date)
        {
            firstName = _firstName;
            lastName = _lastName;
            age = DateTime.Now.Year - date.Year;

            // output
            string output = "Full Name \t : " + firstName + " " + lastName
                + "\n" + "Age \t\t : " + age;

            MessageBox.Show(output, "Student Info",
                 MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // create a method with a return type : string & has parameters
        private string GetFullName(string _firstName, string _lastName)
        {
            return _firstName + " " + _lastName;
        }

        // create a method with a return type : int & has a parameter
        private int GetAge(DateTime date)
        {
            return DateTime.Now.Year - date.Year;
        }

        // create method to invoke methods with return type and parameters
        private void DisplayInfo()
        {
            // output
            string output = "Full Name \t : " + GetFullName(txtFirstName.Text, txtLastName.Text)
                + "\n" + "Age \t\t : " + GetAge(dtpDOB.Value);

            MessageBox.Show(output, "Student Info",
                 MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
