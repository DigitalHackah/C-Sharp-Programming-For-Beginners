﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DatabaseDemo1
{
    /// <summary>
    /// Interaction logic for AddUser.xaml
    /// </summary>
    public partial class AddUser : Window
    {
        public AddUser()
        {
            InitializeComponent();
        }

        private void btnSaveUser_Click(object sender, RoutedEventArgs e)
        {
            CreateUser();
        }

        private void winAddUser_Loaded(object sender, RoutedEventArgs e)
        {
            txtFirstName.Focus();
            btnSaveUser.IsDefault = true;
        }

        // create and save user
        private void CreateUser()
        {
            User u = new DatabaseDemo1.User();

            u.FirstName = txtFirstName.Text;
            u.LastName = txtLastName.Text;
            u.Username = txtUsername.Text;
            u.Password = User.GetPasswordHash(txtPassword);

            if(User.SaveNewUser(u) == true)
            {
                MessageBox.Show("User saved successfully");
                ClearControls();
            }
        }

        // clear controls
        private void ClearControls()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            txtFirstName.Focus();
        }
    }
}
