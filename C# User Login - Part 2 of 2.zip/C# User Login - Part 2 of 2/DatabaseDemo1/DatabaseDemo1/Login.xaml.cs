﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DatabaseDemo1
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        // public variable/property to test if unique user is found
        public static bool IsUserFound = false;

        public Login()
        {
            InitializeComponent();
        }

        private void winLogin_Loaded(object sender, RoutedEventArgs e)
        {
            btnLogin.IsDefault = true;
            txtUsername.Focus();
        }

        private bool GetUniqueUser()
        {
            User u = User.GetUser(txtUsername.Text, User.GetPasswordHash(txtPassword));

            if(u != null)
            {
                UniqueObject.UniqueUser = u;
                IsUserFound = true;
            }

            return IsUserFound;
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if(GetUniqueUser() == true)
            {
                this.Close();
            }
            else
            {
                MessageBox.Show("Incorrect usename or password");
                txtUsername.SelectAll();
            }
        }
    }
}
