﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
// import namespace to have access to timer class
using System.Windows.Threading;

namespace DatabaseDemo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer;

        public MainWindow()
        {
            InitializeComponent();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.IsEnabled = true;
            timer.Tick += Timer_Tick;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblDate.Text = DateTime.Now.ToLongDateString();
            lblTime.Text = DateTime.Now.ToLongTimeString();

            if(Login.IsUserFound == true)
            {
                lblUser.Text = UniqueObject.UniqueUser.FirstName + " " + UniqueObject.UniqueUser.LastName;
            }
        }

        private void winMain_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void btnAddNewProduct_Click(object sender, RoutedEventArgs e)
        {
            // create window instance and show it
            AddProduct win = new DatabaseDemo1.AddProduct();
            win.ShowDialog();
        }

        private void btnShowProducts_Click(object sender, RoutedEventArgs e)
        {
            // create window instance and show it
            ShowProduct win = new DatabaseDemo1.ShowProduct();
            win.ShowDialog();
        }

        private void btnAddNewUser_Click(object sender, RoutedEventArgs e)
        {
            AddUser win = new DatabaseDemo1.AddUser();
            win.ShowDialog();
        }

        private void btnUserLogin_Click(object sender, RoutedEventArgs e)
        {
            Login win = new DatabaseDemo1.Login();
            win.ShowDialog();
        }
    }
}
