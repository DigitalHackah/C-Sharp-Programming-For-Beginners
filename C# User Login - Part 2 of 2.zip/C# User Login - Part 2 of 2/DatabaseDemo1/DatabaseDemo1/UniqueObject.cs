﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseDemo1
{
    // Singleton Design Pattern
    class UniqueObject
    {
        private static User instance;
        private static object _lockObject = new object();

        public static User UniqueUser
        {
            get
            {
                if (instance == null)
                {
                    lock (_lockObject)
                    {
                        if (instance == null)
                        {
                            instance = new User(); // At any given instantiation we expect 1 object of this class
                        }
                    }
                }

                return instance;
            }
            set
            {
                instance = value;
            }
        }
    }
}
