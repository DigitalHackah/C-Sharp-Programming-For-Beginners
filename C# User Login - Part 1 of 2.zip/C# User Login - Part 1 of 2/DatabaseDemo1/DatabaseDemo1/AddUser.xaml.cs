﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
// for password hash
using System.IO;
using System.Security.Cryptography;

namespace DatabaseDemo1
{
    /// <summary>
    /// Interaction logic for AddUser.xaml
    /// </summary>
    public partial class AddUser : Window
    {
        public AddUser()
        {
            InitializeComponent();
        }

        private void btnSaveUser_Click(object sender, RoutedEventArgs e)
        {
            CreateUser();
        }

        private void winAddUser_Loaded(object sender, RoutedEventArgs e)
        {
            txtFirstName.Focus();
            btnSaveUser.IsDefault = true;
        }

        // hash password
        private string GetPasswordHash(string password)
        {
            // hash algorithm
            HashAlgorithm sha = SHA256.Create();

            // generate hash
            byte[] hashData = sha.ComputeHash(UnicodeEncoding.Default.GetBytes(password));

            // return password hash
            return Convert.ToBase64String(hashData);
        }

        // create and save user
        private void CreateUser()
        {
            User u = new DatabaseDemo1.User();

            u.FirstName = txtFirstName.Text;
            u.LastName = txtLastName.Text;
            u.Username = txtUsername.Text;
            u.Password = GetPasswordHash(txtPassword.Password);

            if(User.SaveNewUser(u) == true)
            {
                MessageBox.Show("User saved successfully");
                ClearControls();
            }
        }

        // clear controls
        private void ClearControls()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
            txtFirstName.Focus();
        }
    }
}
