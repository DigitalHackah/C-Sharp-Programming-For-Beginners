﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace DatabaseDemo1
{
    class User
    {
        // class design : attributes/properties
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        // database address
        private static string connString = "Data Source=DESKTOP-U1TC15P;Initial Catalog=LiquorStoreDB;Integrated Security=True";

        // method to save user to database
        public static bool SaveNewUser(User p)
        {
            bool isSaved = false;

            SqlConnection conn = new SqlConnection(connString);
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_AddNewUser";

            // sql command syntax to add parameters
            cmd.Parameters.Add(new SqlParameter("@FirstName", p.FirstName));
            cmd.Parameters.Add(new SqlParameter("@LastName", p.LastName));
            cmd.Parameters.Add(new SqlParameter("@Username", p.Username));
            cmd.Parameters.Add(new SqlParameter("@Password", p.Password));

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                isSaved = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK,
                     MessageBoxImage.Error);
            }
            finally
            {
                conn.Close(); // this code executes regardless
            }

            return isSaved;
        }

    }
}
